#ifndef _PWM_H_
#define _PWM_H_
#include "stm32f10x.h"//Lib
#include "stm32f10x_rcc.h"//it's clock
#include "stm32f10x_gpio.h"//it's io
void pwm_init(void);

#endif
