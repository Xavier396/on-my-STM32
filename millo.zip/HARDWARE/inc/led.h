#ifndef _LED_H_

#define _LED_H_
#include "stm32f10x.h"//it's lib function
#include "stm32f10x_gpio.h"//it's io
#include "stm32f10x_rcc.h"//it's clock
void led_Init(void);
void speak_init(void);







#endif
