#ifndef _MOTOR_H_

#define _MOTOR_H_
#include "stm32f10x.h"//it's lib function
#include "stm32f10x_gpio.h"//it's io
#include "stm32f10x_rcc.h"//it's clock
void motor_Init(void);







#endif
